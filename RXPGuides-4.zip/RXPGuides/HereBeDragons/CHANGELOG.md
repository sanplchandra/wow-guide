# Lib: HereBeDragons

## [2.06-release](https://github.com/Nevcairiel/HereBeDragons/tree/2.06-release) (2021-05-08)
[Full Changelog](https://github.com/Nevcairiel/HereBeDragons/compare/2.05-release...2.06-release) [Previous Releases](https://github.com/Nevcairiel/HereBeDragons/releases)

- Fixup Luacheck  
- Update API check to be independent of WoW version  
- Add transform and worldmap data for BC  
